# Workshop upgrade (colour + life)

Changed files:
- src/simulation/world/workshopTheme.ts  (NEW: colors, 3 themes)
- src/simulation/world/WorkshopDecor.ts  (NEW: props, lights, animation)
- src/simulation/world/WorldManager.ts   (uses the theme for materials)
- src/simulation/core/Stage.ts           (warm background + lights)
- src/simulation/SceneManager.ts         (starts and updates the decor)

Not touched: office.glb, character.glb, API key code, teams, stores.

Switch look: edit ACTIVE_THEME in workshopTheme.ts -> 'cozy' | 'night' | 'clean'.
Change any color: edit the hex numbers in the same file.
Lamps too bright/dark: change `lamp.intensity` in the theme.
Don't want something: delete its build...() call in the WorkshopDecor constructor.

Run: npm install, then npm run dev, open http://localhost:3000/the-delegation
