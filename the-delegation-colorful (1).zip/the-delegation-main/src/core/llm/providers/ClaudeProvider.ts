import { LLMMessage, LLMProvider, LLMResponse, LLMToolCall, LLMToolDefinition } from '../types';

const API_URL = 'https://api.anthropic.com/v1/messages';
const API_VERSION = '2023-06-01';
/** Enough room for answers (and for Opus' built-in thinking) without needing streaming. */
const MAX_TOKENS = 16000;

type Block = Record<string, any>;
interface ClaudeMessage { role: 'user' | 'assistant'; content: Block[] }

/**
 * ClaudeProvider — lets any agent use Anthropic Claude models.
 * Called straight from the browser with the user's own key (BYOK), the same
 * way the Gemini provider works. Text + tool calling + images are supported.
 */
export class ClaudeProvider implements LLMProvider {
  constructor(private apiKey: string) {}

  async generateCompletion(
    messages: LLMMessage[],
    tools?: LLMToolDefinition[],
    systemInstruction?: string,
    modelName: string = 'claude-sonnet-5-5',
  ): Promise<LLMResponse> {
    const claudeMessages = this.mapMessages(messages);

    const body: Record<string, any> = {
      model: modelName,
      max_tokens: MAX_TOKENS,
      messages: claudeMessages,
    };
    if (systemInstruction) body.system = systemInstruction;
    if (tools && tools.length > 0) {
      body.tools = tools.map((t) => ({
        name: t.function.name,
        description: t.function.description,
        input_schema: { type: 'object', properties: {}, ...(t.function.parameters || {}) },
      }));
    }

    const res = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': this.apiKey,
        'anthropic-version': API_VERSION,
        // Required by Anthropic when the call is made directly from a browser.
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify(body),
    });

    const data: any = await res.json().catch(() => null);
    if (!res.ok) {
      const msg = data?.error?.message || res.statusText || 'Unknown error';
      throw new Error(`Claude API error ${res.status}: ${msg}`);
    }

    let text: string | null = null;
    const toolCalls: LLMToolCall[] = [];
    for (const block of data.content || []) {
      if (block.type === 'text' && block.text) {
        text = (text || '') + block.text;
      } else if (block.type === 'tool_use') {
        toolCalls.push({
          id: block.id,
          type: 'function',
          function: { name: block.name, arguments: JSON.stringify(block.input ?? {}) },
        });
      }
    }

    const u = data.usage || {};
    const promptTokens =
      (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
    const completionTokens = u.output_tokens || 0;

    return {
      content: text,
      tool_calls: toolCalls.length > 0 ? toolCalls : undefined,
      usage: { promptTokens, completionTokens, totalTokens: promptTokens + completionTokens },
      finishReason: data.stop_reason,
      raw: data, // contains `model`, used by the cost tracker
      request: { contents: claudeMessages, systemInstruction, tools: body.tools },
    };
  }

  /**
   * Convert the app's history to Claude's format.
   * Claude requires every tool_use to be answered by a tool_result in the next
   * user turn, but this app never stores tool results — so we add a short
   * "OK" result automatically. Also guarantees: starts with user, alternates.
   */
  private mapMessages(messages: LLMMessage[]): ClaudeMessage[] {
    const out: ClaudeMessage[] = [];
    let pending: string[] = [];

    const resultBlocks = (): Block[] => {
      const blocks = pending.map((id) => ({ type: 'tool_result', tool_use_id: id, content: 'OK' }));
      pending = [];
      return blocks;
    };
    const push = (role: 'user' | 'assistant', blocks: Block[]) => {
      if (blocks.length === 0) return;
      const last = out[out.length - 1];
      if (last && last.role === role) last.content.push(...blocks);
      else out.push({ role, content: blocks });
    };
    const safeId = (id: string) => (id || '').replace(/[^a-zA-Z0-9_-]/g, '') || `call_${Math.random().toString(36).slice(2, 10)}`;

    for (const m of messages) {
      if (m.role === 'system') continue;

      if (m.role === 'assistant') {
        if (pending.length > 0) push('user', [...resultBlocks(), { type: 'text', text: '(continued)' }]);
        const blocks: Block[] = [];
        if (m.content && m.content.trim()) blocks.push({ type: 'text', text: m.content });
        for (const tc of m.tool_calls || []) {
          let input: any = {};
          try { input = JSON.parse(tc.function.arguments || '{}'); } catch { /* keep {} */ }
          const id = safeId(tc.id);
          blocks.push({ type: 'tool_use', id, name: tc.function.name, input });
          pending.push(id);
        }
        push('assistant', blocks);
        continue;
      }

      // user or tool
      const blocks: Block[] = [...resultBlocks()];
      for (const img of m.images || []) {
        const match = img.match(/^data:(image\/[a-z+.-]+);base64,(.+)$/);
        blocks.push({
          type: 'image',
          source: { type: 'base64', media_type: match ? match[1] : 'image/jpeg', data: match ? match[2] : img },
        });
      }
      const text = m.role === 'tool' ? `[Tool result${m.name ? ` from ${m.name}` : ''}]: ${m.content}` : m.content;
      if (text && text.trim()) blocks.push({ type: 'text', text });
      push('user', blocks);
    }

    // Close any tool_use left open, and never end on an assistant turn.
    if (pending.length > 0) push('user', [...resultBlocks(), { type: 'text', text: 'Continue.' }]);
    if (out.length > 0 && out[out.length - 1].role === 'assistant') {
      push('user', [{ type: 'text', text: 'Continue.' }]);
    }
    // Must start with a user turn.
    if (out.length === 0 || out[0].role !== 'user') {
      out.unshift({ role: 'user', content: [{ type: 'text', text: '(earlier conversation omitted)' }] });
    }
    return out;
  }
}
