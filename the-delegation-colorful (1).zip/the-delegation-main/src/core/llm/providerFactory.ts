import { LLMConfig, LLMProvider } from './types';
import { GeminiProvider } from './providers/GeminiProvider';
import { ClaudeProvider } from './providers/ClaudeProvider';

export const isClaudeModel = (model: string | undefined): boolean =>
  !!model && model.toLowerCase().startsWith('claude');

/** Picks Gemini or Claude depending on the model name, and checks the matching key. */
export function createTextProvider(model: string, config: LLMConfig): LLMProvider {
  if (isClaudeModel(model)) {
    if (!config.anthropicApiKey) {
      throw new Error(`Claude API key is required for model "${model}". Add it in the key menu (top right), or pick a Gemini model for this agent.`);
    }
    return new ClaudeProvider(config.anthropicApiKey);
  }
  if (!config.apiKey) {
    throw new Error(`Gemini API key is required for model "${model}". Add it in the key menu (top right), or pick a Claude model for this agent.`);
  }
  return new GeminiProvider(config.apiKey);
}
