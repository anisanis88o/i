/**
 * Workshop look & feel.
 * Change ACTIVE_THEME to 'cozy' | 'night' | 'clean' to switch the whole room.
 * All colors are plain hex numbers (0xRRGGBB) so they are easy to edit.
 */

export interface SurfaceStyle {
  color: number;
  roughness?: number;
  metalness?: number;
  /** Keep the original grid texture of the model (multiplied by color). */
  keepTexture?: boolean;
  emissive?: number;
  emissiveIntensity?: number;
}

export interface WorkshopTheme {
  name: string;
  background: number;
  ambient: { color: number; intensity: number };
  sun: { color: number; goldenColor: number; intensity: number };
  /** Point-light color + base intensity used by lamps. */
  lamp: { color: number; intensity: number };
  /** First rule whose keyword is contained in the mesh name wins. */
  rules: Array<[string, SurfaceStyle]>;
  fallback: SurfaceStyle;
  rugs: { base: number; inner: number; accent: number };
  leaf: number;
  pot: number;
}

const cozy: WorkshopTheme = {
  name: 'Cozy Workshop',
  background: 0xf3e6d3,
  ambient: { color: 0xfff1dd, intensity: 0.95 * Math.PI },
  sun: { color: 0xffe6c2, goldenColor: 0xffb878, intensity: 0.75 * Math.PI },
  lamp: { color: 0xffc27a, intensity: 5 },
  rules: [
    ['work-desk', { color: 0xc99663, roughness: 0.8, metalness: 0.02 }],
    ['cafe-table', { color: 0xb9794c, roughness: 0.75, metalness: 0.02 }],
    ['work-chair', { color: 0x3f9aa0, roughness: 0.9, metalness: 0.02 }],
    ['chair', { color: 0xd9674f, roughness: 0.85, metalness: 0.02 }],
    ['flexo', { color: 0xf5c342, roughness: 0.5, metalness: 0.2, emissive: 0xffb347, emissiveIntensity: 0.55 }],
    ['laptop', { color: 0x8d97ab, roughness: 0.45, metalness: 0.5, emissive: 0x4a90ff, emissiveIntensity: 0.12 }],
    ['floor', { color: 0xe2bd8f, roughness: 0.85, metalness: 0.02, keepTexture: true }],
    ['counter', { color: 0x8a5a3b, roughness: 0.7, metalness: 0.03 }],
    ['cabinet', { color: 0x6e4b3a, roughness: 0.75, metalness: 0.03 }],
    ['plant', { color: 0x58a860, roughness: 0.9, metalness: 0 }],
    ['pc', { color: 0x2f3648, roughness: 0.4, metalness: 0.4, emissive: 0x4da3ff, emissiveIntensity: 0.1 }],
    ['board', { color: 0xfff6e2, roughness: 0.6, metalness: 0 }],
    ['sofa', { color: 0xb8566f, roughness: 0.95, metalness: 0 }],
  ],
  fallback: { color: 0xe8d9c3, roughness: 0.85, metalness: 0.03 },
  rugs: { base: 0x7a4a5c, inner: 0xe9c88f, accent: 0x9b6bd1 },
  leaf: 0x4f9f5a,
  pot: 0xc4704a,
};

const night: WorkshopTheme = {
  name: 'Night Workshop',
  background: 0x1b1f33,
  ambient: { color: 0x8fa2ff, intensity: 0.5 * Math.PI },
  sun: { color: 0x9db4ff, goldenColor: 0x7f8cff, intensity: 0.35 * Math.PI },
  lamp: { color: 0xffb25e, intensity: 9 },
  rules: [
    ['work-desk', { color: 0x6d4a35, roughness: 0.8 }],
    ['cafe-table', { color: 0x7b4f36, roughness: 0.75 }],
    ['work-chair', { color: 0x2d6f8f, roughness: 0.9 }],
    ['chair', { color: 0xa84e4e, roughness: 0.85 }],
    ['flexo', { color: 0xffc857, roughness: 0.5, emissive: 0xffa23a, emissiveIntensity: 1.0 }],
    ['laptop', { color: 0x5b647a, roughness: 0.45, metalness: 0.5, emissive: 0x4a90ff, emissiveIntensity: 0.35 }],
    ['floor', { color: 0x6a5a6e, roughness: 0.85, keepTexture: true }],
    ['counter', { color: 0x4d3427, roughness: 0.7 }],
    ['cabinet', { color: 0x3f2d28, roughness: 0.75 }],
    ['plant', { color: 0x3f8a52, roughness: 0.9 }],
    ['pc', { color: 0x222839, roughness: 0.4, metalness: 0.4, emissive: 0x4da3ff, emissiveIntensity: 0.25 }],
    ['board', { color: 0xd8dcf0, roughness: 0.6 }],
    ['sofa', { color: 0x7a3d63, roughness: 0.95 }],
  ],
  fallback: { color: 0x8a7e96, roughness: 0.85 },
  rugs: { base: 0x3a2f55, inner: 0x8b6fbf, accent: 0x5ea0ff },
  leaf: 0x3a7d4c,
  pot: 0x8a4f3a,
};

const clean: WorkshopTheme = {
  name: 'Clean Light',
  background: 0xeef2f5,
  ambient: { color: 0xffffff, intensity: 1.0 * Math.PI },
  sun: { color: 0xffffff, goldenColor: 0xfff0d8, intensity: 0.6 * Math.PI },
  lamp: { color: 0xffe2b0, intensity: 3 },
  rules: [
    ['work-desk', { color: 0xe8d6bc, roughness: 0.8 }],
    ['cafe-table', { color: 0xe3c9a6, roughness: 0.75 }],
    ['work-chair', { color: 0x6fb7c4, roughness: 0.9 }],
    ['chair', { color: 0xf09a86, roughness: 0.85 }],
    ['flexo', { color: 0xffd86b, roughness: 0.5, emissive: 0xffc247, emissiveIntensity: 0.4 }],
    ['laptop', { color: 0xb9c1d1, roughness: 0.45, metalness: 0.4 }],
    ['floor', { color: 0xf4efe6, roughness: 0.85, keepTexture: true }],
    ['counter', { color: 0xc9a888, roughness: 0.7 }],
    ['cabinet', { color: 0xb59a86, roughness: 0.75 }],
    ['plant', { color: 0x6cbc74, roughness: 0.9 }],
    ['pc', { color: 0x4a5368, roughness: 0.4, metalness: 0.3, emissive: 0x4da3ff, emissiveIntensity: 0.08 }],
    ['board', { color: 0xffffff, roughness: 0.6 }],
    ['sofa', { color: 0xd98aa0, roughness: 0.95 }],
  ],
  fallback: { color: 0xf0e8dc, roughness: 0.85 },
  rugs: { base: 0xc7b5d9, inner: 0xf6ead0, accent: 0xa98be0 },
  leaf: 0x66b36f,
  pot: 0xd99a78,
};

export const THEMES = { cozy, night, clean } as const;
export type ThemeKey = keyof typeof THEMES;

/** ← Change this one word to restyle the whole workshop. */
export const ACTIVE_THEME: ThemeKey = 'cozy';
export const WORKSHOP_THEME: WorkshopTheme = THEMES[ACTIVE_THEME];

export function styleFor(theme: WorkshopTheme, meshName: string): SurfaceStyle {
  const n = meshName.toLowerCase();
  for (const [key, style] of theme.rules) {
    if (n.includes(key)) return style;
  }
  return theme.fallback;
}
