import * as THREE from 'three/webgpu';
import { PoiManager } from './PoiManager';
import { WorkshopTheme } from './workshopTheme';

/**
 * WorkshopDecor — adds colour, small props and "life" on top of office.glb
 * WITHOUT modifying the model file.
 *
 * Adds: rugs, floor lamps, desk-lamp lights, mugs with steam, books, trees,
 * floating dust motes, swaying plants, glowing monitors that wake up when an
 * agent works at the desk, and a slow "golden hour" light cycle.
 *
 * Everything lives in `this.root` (a child of the scene, NOT of the office),
 * so clicking/raycasting on the floor and the NavMesh are never affected.
 */

interface Station {
  light: THREE.PointLight;
  flexoMat: THREE.MeshStandardNodeMaterial | null;
  pcMat: THREE.MeshStandardNodeMaterial | null;
  flexoBase: number;
  pcBase: number;
  poiId: string | null;
  level: number;
  phase: number;
}

interface AmbientLamp {
  light: THREE.PointLight;
  base: number;
  phase: number;
}

const _dummy = new THREE.Object3D();

export class WorkshopDecor {
  private root = new THREE.Group();
  private time = 0;

  private stations: Station[] = [];
  private lamps: AmbientLamp[] = [];
  private plants: Array<{ obj: THREE.Object3D; baseZ: number; baseX: number; phase: number }> = [];

  private dust: THREE.InstancedMesh | null = null;
  private dustSeeds: Array<{ x: number; y: number; z: number; sp: number; ph: number }> = [];

  private steam: THREE.InstancedMesh | null = null;
  private steamSources: THREE.Vector3[] = [];
  private steamParticles: Array<{ src: number; age: number; life: number; dx: number; dz: number }> = [];

  private accentRugMat: THREE.MeshStandardNodeMaterial | null = null;
  private sunDay: THREE.Color;
  private sunGolden: THREE.Color;

  constructor(
    private scene: THREE.Scene,
    private office: THREE.Object3D,
    private sun: THREE.DirectionalLight,
    private ambient: THREE.AmbientLight,
    private poiManager: PoiManager,
    private theme: WorkshopTheme,
  ) {
    this.sunDay = new THREE.Color(theme.sun.color);
    this.sunGolden = new THREE.Color(theme.sun.goldenColor);
    this.scene.add(this.root);
    this.office.updateMatrixWorld(true);

    this.buildRugs();
    this.buildTable();
    this.buildCounter();
    this.buildFloorLamps();
    this.buildTrees();
    this.buildStations();
    this.collectPlants();
    this.buildDust();
    this.buildSteam();
  }

  // ── helpers ──────────────────────────────────────────────────

  private worldPos(name: string): THREE.Vector3 | null {
    const o = this.office.getObjectByName(name);
    if (!o) return null;
    return o.getWorldPosition(new THREE.Vector3());
  }

  private std(color: number, roughness = 0.85, metalness = 0.02): THREE.MeshStandardNodeMaterial {
    return new THREE.MeshStandardNodeMaterial({ color: new THREE.Color(color), roughness, metalness });
  }

  private add(mesh: THREE.Mesh, x: number, y: number, z: number, shadow = true): THREE.Mesh {
    mesh.position.set(x, y, z);
    mesh.castShadow = shadow;
    mesh.receiveShadow = true;
    this.root.add(mesh);
    return mesh;
  }

  // ── rugs ─────────────────────────────────────────────────────

  private rug(cx: number, cz: number, w: number, d: number, outer: THREE.MeshStandardNodeMaterial, inner: number, round = false) {
    const h = 0.02;
    const geo = (a: number, b: number) =>
      round ? new THREE.CylinderGeometry(a / 2, a / 2, h, 48) : new THREE.BoxGeometry(a, h, b);
    const base = new THREE.Mesh(geo(w, d), outer);
    base.position.set(cx, 0.011, cz);
    base.receiveShadow = true;
    this.root.add(base);
    const top = new THREE.Mesh(geo(w * 0.82, d * 0.8), this.std(inner, 1, 0));
    top.position.set(cx, 0.014, cz);
    top.receiveShadow = true;
    this.root.add(top);
  }

  private buildRugs() {
    const t = this.theme.rugs;
    const table = this.worldPos('static-cafe-table');
    if (table) this.rug(table.x, table.z, 2.6, 2.6, this.std(t.base, 1, 0), t.inner, true);

    const hub = this.worldPos('poi-idle-area-hub');
    if (hub) this.rug(hub.x, hub.z, 2.6, 1.7, this.std(t.base, 1, 0), t.inner);

    const board = this.worldPos('poi-idle-area-boardroom');
    if (board) {
      this.accentRugMat = this.std(t.accent, 1, 0);
      this.rug(board.x, board.z, 2.4, 1.4, this.accentRugMat, t.inner);
    }

    // big rug under the desks (centre of the 4 work desks)
    this.rug(2.35, -2.2, 4.6, 4.4, this.std(t.base, 1, 0), t.inner);
  }

  /** Recolor the "meeting" rug with the active team colour. */
  public setAccent(color: string) {
    this.accentRugMat?.color.set(color);
  }

  // ── props ────────────────────────────────────────────────────

  private mug(x: number, y: number, z: number, color: number) {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.042, 0.085, 16), this.std(color, 0.5, 0.05));
    this.add(body, x, y + 0.0425, z, false);
    const coffee = new THREE.Mesh(new THREE.CylinderGeometry(0.043, 0.043, 0.004, 16), this.std(0x3b2418, 0.3, 0));
    this.add(coffee, x, y + 0.08, z, false);
    this.steamSources.push(new THREE.Vector3(x, y + 0.09, z));
  }

  private buildTable() {
    const table = this.worldPos('static-cafe-table');
    if (!table) return;
    const top = 0.49;
    this.mug(table.x + 0.14, top, table.z + 0.06, 0xffffff);
    this.mug(table.x - 0.16, top, table.z - 0.1, 0xf2a65a);
    // little plate with a cookie
    const plate = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.012, 20), this.std(0xffffff, 0.4, 0));
    this.add(plate, table.x + 0.02, top + 0.006, table.z - 0.2, false);
    const cookie = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.02, 14), this.std(0xc98a4b, 0.9, 0));
    this.add(cookie, table.x + 0.02, top + 0.022, table.z - 0.2, false);
  }

  private buildCounter() {
    const c = this.worldPos('static-counter');
    if (!c) return;
    const top = 0.55;
    const colors = [0xd9534f, 0x4a90d9, 0xf0ad4e, 0x5cb85c];
    colors.forEach((col, i) => {
      const b = new THREE.Mesh(new THREE.BoxGeometry(0.26 - i * 0.02, 0.045, 0.19), this.std(col, 0.8, 0));
      this.add(b, c.x + 0.7 + (i % 2) * 0.015, top + 0.0225 + i * 0.045, c.z, false);
    });
    this.mug(c.x - 0.05, top, c.z + 0.05, 0x7fb3d5);
  }

  private floorLamp(x: number, z: number) {
    const metal = this.std(0x3a3a44, 0.4, 0.6);
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.04, 20), metal);
    this.add(base, x, 0.02, z);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 1.25, 8), metal);
    this.add(pole, x, 0.65, z);
    const shadeMat = new THREE.MeshStandardNodeMaterial({
      color: new THREE.Color(0xfff0d0),
      roughness: 0.9,
      metalness: 0,
    });
    shadeMat.emissive = new THREE.Color(this.theme.lamp.color);
    shadeMat.emissiveIntensity = 0.9;
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.2, 0.26, 20, 1, true), shadeMat);
    shadeMat.side = THREE.DoubleSide;
    this.add(shade, x, 1.38, z, false);

    const light = new THREE.PointLight(this.theme.lamp.color, this.theme.lamp.intensity, 6, 2);
    light.position.set(x, 1.3, z);
    this.root.add(light);
    this.lamps.push({ light, base: this.theme.lamp.intensity, phase: Math.random() * 10 });
  }

  private buildFloorLamps() {
    this.floorLamp(-2.85, 0.75);
    this.floorLamp(4.5, 1.2);
  }

  private tree(x: number, z: number, scale = 1) {
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.26 * scale, 0.2 * scale, 0.34 * scale, 14), this.std(this.theme.pot, 0.9, 0));
    this.add(pot, x, 0.17 * scale, z);
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.04 * scale, 0.06 * scale, 0.5 * scale, 8), this.std(0x6b4a2f, 0.9, 0));
    this.add(trunk, x, 0.55 * scale, z, false);
    const leafMat = this.std(this.theme.leaf, 0.9, 0);
    const blobs: Array<[number, number, number, number]> = [
      [0, 0.95, 0, 0.34],
      [0.2, 0.78, 0.08, 0.24],
      [-0.18, 0.8, -0.06, 0.25],
      [0.02, 1.2, 0.04, 0.22],
    ];
    blobs.forEach(([dx, dy, dz, r]) => {
      const b = new THREE.Mesh(new THREE.IcosahedronGeometry(r * scale, 1), leafMat);
      this.add(b, x + dx * scale, dy * scale, z + dz * scale);
    });
  }

  private buildTrees() {
    this.tree(4.4, -4.4, 1.0);
    this.tree(-0.4, -4.45, 0.8);
  }

  // ── desks / lamps / monitors ────────────────────────────────

  private buildStations() {
    const pcs: Array<{ pos: THREE.Vector3; mat: THREE.MeshStandardNodeMaterial | null }> = [];
    const flexos: Array<{ pos: THREE.Vector3; mat: THREE.MeshStandardNodeMaterial | null }> = [];

    this.office.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      const mat = mesh.material as THREE.MeshStandardNodeMaterial;
      const pos = mesh.getWorldPosition(new THREE.Vector3());
      if (o.name.startsWith('static-pc')) pcs.push({ pos, mat });
      else if (o.name.startsWith('static-flexo')) flexos.push({ pos, mat });
      else if (o.name.startsWith('static-laptop')) pcs.push({ pos, mat });
    });

    const nearest = <T extends { pos: THREE.Vector3 }>(list: T[], p: THREE.Vector3): T | null => {
      let best: T | null = null;
      let bd = Infinity;
      for (const it of list) {
        const d = (it.pos.x - p.x) ** 2 + (it.pos.z - p.z) ** 2;
        if (d < bd) { bd = d; best = it; }
      }
      return best;
    };

    const workPois = this.poiManager.getPoisByPrefix('sit_work');
    const nearestPoi = (p: THREE.Vector3): string | null => {
      let best: string | null = null;
      let bd = Infinity;
      for (const poi of workPois) {
        const d = (poi.position.x - p.x) ** 2 + (poi.position.z - p.z) ** 2;
        if (d < bd) { bd = d; best = poi.id; }
      }
      return best;
    };

    flexos.forEach((f, i) => {
      const pc = nearest(pcs, f.pos);
      const light = new THREE.PointLight(this.theme.lamp.color, this.theme.lamp.intensity * 0.4, 3.2, 2);
      light.position.set(f.pos.x, f.pos.y + 0.4, f.pos.z);
      this.root.add(light);
      this.stations.push({
        light,
        flexoMat: f.mat,
        pcMat: pc?.mat ?? null,
        flexoBase: f.mat?.emissiveIntensity ?? 0.5,
        pcBase: pc?.mat?.emissiveIntensity ?? 0.1,
        poiId: nearestPoi(pc?.pos ?? f.pos),
        level: 0,
        phase: i * 1.7,
      });
    });

    // laptop on the counter (its own station without a lamp)
    for (const lp of pcs.filter((p) => p.pos.z > 3)) {
      this.stations.push({
        light: new THREE.PointLight(0x000000, 0, 1),
        flexoMat: null,
        pcMat: lp.mat,
        flexoBase: 0,
        pcBase: lp.mat?.emissiveIntensity ?? 0.1,
        poiId: nearestPoi(lp.pos),
        level: 0,
        phase: 0.5,
      });
    }
  }

  private collectPlants() {
    this.office.traverse((o) => {
      if (o.name.startsWith('static-plant')) {
        this.plants.push({ obj: o, baseZ: o.rotation.z, baseX: o.rotation.x, phase: Math.random() * 6 });
      }
    });
  }

  // ── particles ────────────────────────────────────────────────

  private buildDust() {
    const count = 70;
    const mat = new THREE.MeshBasicNodeMaterial({
      color: new THREE.Color(0xfff3d6),
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    this.dust = new THREE.InstancedMesh(new THREE.SphereGeometry(0.014, 5, 4), mat, count);
    this.dust.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.dust.frustumCulled = false;
    for (let i = 0; i < count; i++) {
      this.dustSeeds.push({
        x: (Math.random() - 0.5) * 9,
        y: 0.4 + Math.random() * 2.4,
        z: (Math.random() - 0.5) * 9,
        sp: 0.15 + Math.random() * 0.3,
        ph: Math.random() * 100,
      });
    }
    this.root.add(this.dust);
  }

  private buildSteam() {
    if (this.steamSources.length === 0) return;
    const per = 5;
    const count = this.steamSources.length * per;
    const mat = new THREE.MeshBasicNodeMaterial({
      color: new THREE.Color(0xffffff),
      transparent: true,
      opacity: 0.35,
      depthWrite: false,
    });
    this.steam = new THREE.InstancedMesh(new THREE.SphereGeometry(0.022, 6, 5), mat, count);
    this.steam.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.steam.frustumCulled = false;
    for (let s = 0; s < this.steamSources.length; s++) {
      for (let k = 0; k < per; k++) {
        this.steamParticles.push({
          src: s,
          age: Math.random() * 2,
          life: 1.6 + Math.random() * 0.8,
          dx: (Math.random() - 0.5) * 0.04,
          dz: (Math.random() - 0.5) * 0.04,
        });
      }
    }
    this.root.add(this.steam);
  }

  // ── per-frame ────────────────────────────────────────────────

  public update(delta: number) {
    const dt = Math.min(delta, 0.1);
    this.time += dt;
    const t = this.time;

    // golden-hour breathing (period ≈ 2.5 min)
    const k = 0.5 + 0.5 * Math.sin(t * 0.04);
    this.sun.color.copy(this.sunDay).lerp(this.sunGolden, k * 0.7);
    this.sun.position.set(10 + 5 * Math.sin(t * 0.04), 20, 10 - 5 * Math.sin(t * 0.04));

    // ambient floor lamps flicker gently
    for (const l of this.lamps) {
      const f = 1 + 0.05 * Math.sin(t * 7 + l.phase) + 0.03 * Math.sin(t * 13.3 + l.phase * 2);
      l.light.intensity = l.base * f;
    }

    // desks wake up when an agent sits there
    for (const s of this.stations) {
      const poi = s.poiId ? this.poiManager.getPoi(s.poiId) : undefined;
      const working = !!poi && poi.occupiedBy !== null;
      s.level += ((working ? 1 : 0) - s.level) * Math.min(1, dt * 3);
      const flick = 1 + 0.04 * Math.sin(t * 9 + s.phase);
      s.light.intensity = this.theme.lamp.intensity * (0.35 + 0.9 * s.level) * flick;
      if (s.flexoMat) s.flexoMat.emissiveIntensity = s.flexoBase * (0.5 + 1.0 * s.level);
      if (s.pcMat) {
        const pulse = 0.5 + 0.5 * Math.sin(t * 5 + s.phase);
        s.pcMat.emissiveIntensity = s.pcBase + s.level * (0.35 + 0.25 * pulse);
      }
    }

    // plants sway
    for (const p of this.plants) {
      p.obj.rotation.z = p.baseZ + 0.025 * Math.sin(t * 1.3 + p.phase);
      p.obj.rotation.x = p.baseX + 0.018 * Math.sin(t * 1.1 + p.phase * 1.7);
    }

    // dust motes
    if (this.dust) {
      this.dustSeeds.forEach((d, i) => {
        const y = 0.4 + ((d.y - 0.4 + t * d.sp * 0.15) % 2.4);
        _dummy.position.set(
          d.x + Math.sin(t * 0.3 * d.sp + d.ph) * 0.35,
          y,
          d.z + Math.cos(t * 0.25 * d.sp + d.ph) * 0.35,
        );
        const tw = 0.6 + 0.4 * Math.sin(t * 1.5 + d.ph);
        _dummy.scale.setScalar(tw);
        _dummy.updateMatrix();
        this.dust!.setMatrixAt(i, _dummy.matrix);
      });
      this.dust.instanceMatrix.needsUpdate = true;
    }

    // steam
    if (this.steam) {
      this.steamParticles.forEach((p, i) => {
        p.age += dt;
        if (p.age > p.life) p.age -= p.life;
        const r = p.age / p.life;
        const src = this.steamSources[p.src];
        _dummy.position.set(
          src.x + p.dx + Math.sin(t * 2 + i) * 0.015 * r,
          src.y + r * 0.28,
          src.z + p.dz,
        );
        _dummy.scale.setScalar(Math.sin(Math.PI * r) * 1.4 + 0.01);
        _dummy.updateMatrix();
        this.steam!.setMatrixAt(i, _dummy.matrix);
      });
      this.steam.instanceMatrix.needsUpdate = true;
    }
  }

  public dispose() {
    this.scene.remove(this.root);
    this.root.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.geometry.dispose();
        const mat = m.material as THREE.Material | THREE.Material[];
        (Array.isArray(mat) ? mat : [mat]).forEach((x) => x.dispose());
      }
    });
  }
}
