# Claude support

New:   src/core/llm/providers/ClaudeProvider.ts, src/core/llm/providerFactory.ts
Edited: types.ts, constants.ts, pricing.ts, AgentBrain.ts, uiStore.ts, Header.tsx, BYOKModal.tsx

1. Click the key button (top right) -> paste Claude key in "Claude API Key" -> Save.
2. Manage Teams -> click an agent -> Model -> choose claude-sonnet-5-5 / claude-opus-5-5 / claude-haiku-5-5.
